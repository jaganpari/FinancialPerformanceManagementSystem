import { Investment } from "../model/Investment";

export interface InvestmentModel {
    list: Investment[],
    errormessage: string,
    investmentObj:Investment
}