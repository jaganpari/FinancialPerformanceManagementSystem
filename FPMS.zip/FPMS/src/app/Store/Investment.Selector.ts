import { createFeatureSelector, createSelector } from "@ngrx/store";
import { InvestmentModel } from "./Investment.Model";

const getInvestmentState=createFeatureSelector<InvestmentModel>('emp')

export const getInvestmentList=createSelector(getInvestmentState,(state)=>{
    return state.list;
});