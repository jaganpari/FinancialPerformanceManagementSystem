import { createReducer, on } from "@ngrx/store";
import { investmentState } from "./Investment.State";
import { addInvestmentSuc, loadInvestmentFail, loadInvestmentSuc } from "./Investment.Action";

const _investmentReducer = createReducer(investmentState,
    on(loadInvestmentSuc, (state, action) => {
        return {
            ...state,
            list: action.list,
            errormessage: ''
        }
    }),
    on(loadInvestmentFail, (state, action) => {
        return {
            ...state,
            list: [],
            errormessage: action.errMsg
        }
    }),
    on(addInvestmentSuc, (state, action) => {
        const _newdata = { ...action.data };
        return {
            ...state,
            list: [...state.list, _newdata],
            errormessage: ''
        }
    }),
);

export function investmentReducer(state: any, action: any) {
    return _investmentReducer(state, action);
}