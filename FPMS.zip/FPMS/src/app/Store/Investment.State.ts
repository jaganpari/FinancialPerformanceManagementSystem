import { InvestmentModel } from "./Investment.Model";

export const investmentState: InvestmentModel = {
    list: [],
    errormessage: "",
    investmentObj: {
        year: 0,
        invested: 0,
        revenue: 0,
        total: 0
    }
}