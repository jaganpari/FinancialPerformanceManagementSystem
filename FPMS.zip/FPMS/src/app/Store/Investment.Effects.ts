import { inject, Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { InvestmentService } from "../service/investment.service";
import { addInvestment, addInvestmentSuc, emptyAction, loadInvestment, loadInvestmentFail, loadInvestmentSuc } from "./Investment.Action";
import { catchError, exhaustMap, map, of, switchMap } from "rxjs";
import { ToastrService } from "ngx-toastr";

@Injectable()
export class investmentEffects {

    actions$ = inject(Actions);
    service = inject(InvestmentService);
    toastr = inject(ToastrService)


    _loadInvestment = createEffect(() =>
        this.actions$.pipe(
            ofType(loadInvestment),
            exhaustMap(() => {
                return this.service.GetAll().pipe(
                    map((data) => {
                        return loadInvestmentSuc({ list: data })
                    }),
                    catchError((err) => of(loadInvestmentFail({ errMsg: err.message })))
                )
            })
        )
    )

    _addInvestment = createEffect(() =>
        this.actions$.pipe(
            ofType(addInvestment),
            switchMap((action) => {
                return this.service.Create(action.data).pipe(
                    switchMap((data) => {
                        return of(addInvestmentSuc({ data: action.data }),
                        this.Showalert('Created Successfully.','pass')
                    )
                    }),
                    catchError((err) => of(this.Showalert(err.message,'fail')))
                )
            })
        )
    )

    Showalert(message: string, response: string) {
        if (response == 'pass') {
            this.toastr.success(message);
        }else{
            this.toastr.error(message);
        }
        return emptyAction();
    }

}