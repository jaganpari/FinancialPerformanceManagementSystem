import { createAction, props } from "@ngrx/store";
import { Investment } from "../model/Investment";

export const LOAD_INVESTMENT = '[investment] getall';
export const LOAD_INVESTMENT_SUCCESS = 'investment getall suc';
export const LOAD_INVESTMENT_FAIL = 'investment getall fail';

export const ADD_INVESTMENT = '[investment] add';
export const ADD_INVESTMENT_SUCC = '[investment] add succ';

export const loadInvestment = createAction(LOAD_INVESTMENT)
export const loadInvestmentSuc = createAction(LOAD_INVESTMENT_SUCCESS, props<{ list: Investment[] }>())
export const loadInvestmentFail = createAction(LOAD_INVESTMENT_FAIL, props<{ errMsg: string }>())

export const addInvestment = createAction(ADD_INVESTMENT,props<{data:Investment}>())
export const addInvestmentSuc = createAction(ADD_INVESTMENT_SUCC, props<{ data:Investment }>())

export const emptyAction = createAction('empty')
