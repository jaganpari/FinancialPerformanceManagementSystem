import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Investment } from '../model/Investment';

@Injectable({
  providedIn: 'root'
})
export class InvestmentService {

  apiUrl = 'http://localhost:3000/investment';

  constructor(private http: HttpClient) { }

  GetAll() {
    return this.http.get<Investment[]>(this.apiUrl);
  }

  Create(data: Investment) {
    return this.http.post(this.apiUrl, data);
  }

}
