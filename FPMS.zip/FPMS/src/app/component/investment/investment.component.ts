import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { AddInvestmentComponent } from '../add-investment/add-investment.component';
import { Investment } from '../../model/Investment';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { loadInvestment } from '../../Store/Investment.Action';
import { getInvestmentList } from '../../Store/Investment.Selector';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-investment',
  imports: [MatCardModule, MatButtonModule, MatDialogModule,
    MatTableModule, CommonModule, MatGridListModule
  ],
  templateUrl: './investment.component.html',
  styleUrl: './investment.component.css'
})
export class InvestmentComponent implements OnInit, OnDestroy {

  investmentList: Investment[] = [];
  dataSource!: MatTableDataSource<Investment>;
  displayedColumns: string[] = ['year', 'invested', 'revenue', 'total'];
  subscription = new Subscription();
  assets: any = [
    { label: 'Gold', count: 150, percent: '25' },
    { label: 'Diamond', count: 250, percent: '25' },
    { label: 'Silver', count: 350, percent: '25' }
  ]

  constructor(private dialog: MatDialog, private store: Store
  ) { }

  yearData: number[] = [];
  totalValue: number[] = [];
  investedValue: number[] = [];
  revenueValue: number[] = [];
  pieLabels: any = [];
  pieCounts: any = [];
  piePercent: any = [];
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  ngOnInit(): void {
    this.GetallInvestment();
  }
  GetallInvestment() {
    this.store.dispatch(loadInvestment())
    this.store.select(getInvestmentList).subscribe(item => {
      console.log(item);
      this.investmentList = item;
      if (this.investmentList != null) {
        this.investmentList.map(o => {
          this.yearData.push(o.year);
          this.investedValue.push(o.invested);
          this.revenueValue.push(o.revenue);
          this.totalValue.push(o.total);
        })
        this.preRenderChart(this.yearData, this.investedValue, this.revenueValue, this.totalValue);
      }
      this.dataSource = new MatTableDataSource(this.investmentList);
    })
  }

  RenderPiechart(chartid: any, charttype: any, data: any) {
    const pieChart = new Chart(chartid, {
      type: charttype,
      data: {
        labels: this.pieLabels,
        datasets: [{
          data: data,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)',
            'rgb(255, 205, 86)'
          ],
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true
      }
    });
  }

  doughnutTotal: number = 0

  preRenderChart(labelData: any, investedValue: any, revenueValue: any, totalValue: any) {
    this.pieLabels = [];
    this.pieCounts = [];
    this.piePercent = [];
    this.doughnutTotal = 0;
    this.assets.map((a: any) => {
      this.pieLabels.push(a.label);
      this.pieCounts.push(a.count);
      this.piePercent.push(a.percent);
      this.doughnutTotal += parseFloat(a.percent);
    });
    this.RenderPiechart('piechart', 'pie', this.pieCounts);
    this.RenderPiechart('doughnutchart', 'doughnut', this.piePercent);
    this.Renderchart(labelData, investedValue, revenueValue, totalValue, 'barchart', 'bar');
    this.Renderchart(labelData, investedValue, revenueValue, totalValue, 'linechart', 'line')
  }

  Renderchart(labelData: any, investedValue: any, revenueValue: any, totalValue: any, chartid: string, charttype: any) {
    const char = new Chart(chartid, {
      type: charttype,
      data: {
        labels: labelData,
        datasets: [
          {
            label: 'INVESTED AMOUNT',
            data: investedValue,
            backgroundColor: 'red'
          },
          {
            label: 'REVENUE',
            data: revenueValue,
            backgroundColor: 'green'
          },
          {
            label: 'TOTAL',
            data: totalValue,
            backgroundColor: 'blue'
          }
        ]
      },
      options: {
        scales: {
          y: {
            beginAtZero: false
          }
        }
      }

    });
  }



  addInvestment() {
    this.openpopup();
  }

  openpopup() {
    this.dialog.open(AddInvestmentComponent, {
      width: '50%',
      exitAnimationDuration: '1000ms',
      enterAnimationDuration: '1000ms'
    }).afterClosed().subscribe(o => {
      this.GetallInvestment();
    });
  }

}
