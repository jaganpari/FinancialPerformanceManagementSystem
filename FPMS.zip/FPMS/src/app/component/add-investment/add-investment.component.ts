import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { Investment } from '../../model/Investment';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Store } from '@ngrx/store';
import { addInvestment } from '../../Store/Investment.Action';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-investment',
  imports: [MatCardModule, ReactiveFormsModule, MatFormFieldModule,
    MatInputModule, MatButtonModule, MatSelectModule, MatDatepickerModule,
    MatIconModule, CommonModule, MatGridListModule
  ],
  providers: [provideNativeDateAdapter()],
  templateUrl: './add-investment.component.html',
  styleUrl: './add-investment.component.css'
})
export class AddInvestmentComponent implements OnInit {

  title = 'Add Investment'
  dialodata: any;
  isEdit = false;
  showReview = false;

  constructor(private store: Store, private ref: MatDialogRef<AddInvestmentComponent>,
    private toastr: ToastrService, @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private route: ActivatedRoute
  ) {

  }
  ngOnInit(): void {
    this.dialodata = this.data;
  }


  investmentForm = new FormGroup({
    year: new FormControl(0, [Validators.required, Validators.min(1)]),
    invested: new FormControl(0, [Validators.required, Validators.min(1)]),
    revenue: new FormControl(0, [Validators.required, Validators.min(1)]),
    total: new FormControl(0, [Validators.required, Validators.min(1)])
  })
  reviewDataSource: any = [];
  reviewValue() {
    if (this.investmentForm.valid) {
      this.showReview = true;
    }
  }

  SaveInvestment() {
    let _data: Investment = {
      year: this.investmentForm.value.year as number,
      invested: this.investmentForm.value.invested as number,
      revenue: this.investmentForm.value.revenue as number,
      total: this.investmentForm.value.total as number

    }
    this.store.dispatch(addInvestment({ data: _data }));
    this.closepopup();
    this.showReview = false;
  }

  closepopup() {
    this.ref.close();
  }

}
