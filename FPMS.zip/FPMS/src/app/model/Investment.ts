export interface Investment{
    year: number;
    total: number;
    invested: number;
    revenue: number;
}