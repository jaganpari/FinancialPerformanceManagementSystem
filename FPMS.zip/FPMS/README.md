# FPMS

The following commands are used for this web application,

npm install

json-server --watch src/data/db.json

ng serve

UI Access URL: http://localhost:4200/

Mock API URL: http://localhost:3000/investment

